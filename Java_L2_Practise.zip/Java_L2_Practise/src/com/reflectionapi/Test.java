package com.reflectionapi;
import java.lang.reflect.*;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample s = new Sample();
		
		Class cls = s.getClass();
		
		System.out.println("Name of the Package is:"+cls.getPackage());
		
		System.out.println("Superclass is :"+cls.getSuperclass());
		
		System.out.println("Name of the class is :"+cls.getName());
		
		Constructor[] c = cls.getConstructors();
		for(Constructor cc : c)
			System.out.println("Constructor Name :"+cc.getName());
		
		Method[] methods = cls.getMethods();
		for(Method mth : methods)
			System.out.println("Private Methods are :"+mth.getName());
		try{
		Method privatemethod = (Method)cls.getDeclaredMethod("getSalary",double.class);
		}catch(NoSuchMethodException e)
		{
			e.printStackTrace();
		}
		
		
		
	}

} //end of Test Class


