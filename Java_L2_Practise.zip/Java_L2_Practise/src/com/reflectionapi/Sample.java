package com.reflectionapi;

public class Sample {
	
double salary;
String name,id;
int age;

public Sample(){
	System.out.println("Constructor-1");
}

public Sample(String n){
	System.out.println("Constructor-2");
	name=n;
}

public Sample (double s,int a){
	System.out.println("Constructor-3");
	salary=s;
	age=a;
}

public Sample(String i,String n,int a ){
	System.out.println("Constructor-4");
	id=i;
	name=n;
	age=a;
}

private double getSalary() {
	return salary;
}
private String getName() {
	return name;
}
private String getId() {
	return id;
}
private int getAge() {
	return age;
}



}
