package com.rmiimpl;
import java.rmi.registry.LocateRegistry; 
import java.rmi.registry.Registry; 
import java.util.*;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{
			 Registry registry = LocateRegistry.getRegistry(null);
			 
			 EmpDetails stub = (EmpDetails)registry.lookup("EmpDetails");
			 
			 List<Employee> list = (List<Employee>)stub.getEmployees();
			 
			 for(Employee e : list)
			 {
				 System.out.println("Employee Name :"+e.getName());
				 System.out.println("Emp Id :"+e.getEmpid());
				 System.out.println("Email ID : "+e.getEmailid());
				 System.out.println("Salary :"+e.getSalary());
				 
			 }
				
		}catch(Exception e){
			e.printStackTrace();
			
		}

	}

}