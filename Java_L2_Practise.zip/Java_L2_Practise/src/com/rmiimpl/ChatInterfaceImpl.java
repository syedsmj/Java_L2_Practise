package com.rmiimpl;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ChatInterfaceImpl extends UnicastRemoteObject implements ChatInterface {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ChatInterfaceImpl() throws RemoteException{
		super();
	}
	
	public int getNumber(String num){
		return Integer.valueOf(num);
		
	}

}
