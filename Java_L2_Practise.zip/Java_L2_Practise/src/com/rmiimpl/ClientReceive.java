package com.rmiimpl;
import java.rmi.*;
import java.util.Scanner;

public class ClientReceive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try{
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Client Enter the Input - ");
			String num = sc.nextLine();
			
			ChatInterfaceImpl ci = (ChatInterfaceImpl)Naming.lookup("rmi://localhost:1900");
			
			System.out.println("Respond from Server - "+ci.getNumber(num));
			
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
