package com.rmiimpl;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface EmpDetails extends Remote {

	public List<Employee> getEmployees() throws Exception;

}
