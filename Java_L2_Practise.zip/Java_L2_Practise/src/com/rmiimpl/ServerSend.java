package com.rmiimpl;
import java.rmi.*;
import java.rmi.registry.LocateRegistry;

public class ServerSend {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try{
			ChatInterfaceImpl ci = new ChatInterfaceImpl();
			
			LocateRegistry.createRegistry(1900);
			
			Naming.rebind("rmi://localhost:1900",ci);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
