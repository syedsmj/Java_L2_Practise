package com.rmiimpl;
import java.rmi.*;

public interface ChatInterface extends Remote {

	public int getNumber(String num);
}
