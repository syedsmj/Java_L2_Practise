package com.rmiimpl;

import java.util.*;

public class ImplExample implements EmpDetails {
	
	public List<Employee> getEmployees() throws Exception
	{
		List<Employee> list = new ArrayList<Employee>();
		Employee e = new Employee();
		e.setEmpid(1001);
		e.setEmailid("xyz@abc.com");
		e.setName("John");
		e.setSalary(25000);
		
		Employee e1 = new Employee();
		e.setEmailid("abc@xyz.com");
		e.setEmpid(1002);
		e.setName("James");
		e.setSalary(27000);
		
		list.add(e);
		list.add(e1);
		
		return list;
		
	}

}
