package com.rmiimpl;
import java.rmi.registry.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;


public class Server extends ImplExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{
			ImplExample obj = new ImplExample();
			
			EmpDetails stub = (EmpDetails)UnicastRemoteObject.exportObject(obj,0);
			
			Registry registry = LocateRegistry.getRegistry();
			
			registry.bind("ImplExample",stub);
			
			System.out.println("Server Ready");
			
			}catch(Exception e){
				e.printStackTrace();
			
		}

	}

}
