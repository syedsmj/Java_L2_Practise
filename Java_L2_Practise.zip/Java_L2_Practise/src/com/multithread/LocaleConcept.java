package com.multithread;

import java.sql.Date;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;

public class LocaleConcept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number :");
		Double num = sc.nextDouble();
		System.out.println("Enter a country code :");
		String countrycode = sc.nextLine();
		System.out.println("Enter a Language Code");
		String langcode = sc.nextLine();
		
		System.out.println("The values enter are as following :"+num+" "+countrycode+" "+langcode);
		sc.close();
		Locale loc = new Locale(countrycode);
		NumberFormat nf = NumberFormat.getInstance(loc);
		
		Date now = new Date(0);
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.LONG,DateFormat.LONG,loc);
		
		System.out.println("Number and date in correct format :"+nf.format(num)+" "+df.format(now));
		
		
	}

}
