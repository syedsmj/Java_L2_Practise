package com.multithread;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.*;

public class Student {

	/* String name;
	String stu_id;
	int age;
	
	 public Student(String n,String id,int a){
		name=n;
		stu_id=id;
		age=a;
		
	}//end of constructor
*/	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner in = new Scanner(System.in);
	System.out.println("Enter No. of Students: ");
	int n = Integer.parseInt(in.nextLine().trim());
	System.out.println("Enter Student Name,ID and Age"); 
	String name=null,stu_id=null;
	int age=0;
	for(int i=0;i<n;i++){
		name=in.next();
		stu_id=in.next();
		age = in.nextInt();
		
	}//end of for loop
	
	//Database Logic
//String databaseURL = "jdbc:derby:studentsdb;create=true";
	String databaseURL = "jdbc:derby://localhost:1527/studentsdb;create=true";
	try{
		Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
		Connection conn = DriverManager.getConnection(databaseURL);
		Statement statement = conn.createStatement();
		String sql;
		{
			sql = "drop table student";
			statement.execute(sql);
			sql = "CREATE TABLE student (stu_id varchar(128),stu_name varchar(128),age int)";
			statement.execute(sql);
			System.out.println("Created student table");
		}//end of if block
		sql = "INSERT INTO student VALUES('"+stu_id+"','"+name+"',"+age+")";
		statement.execute(sql);
		System.out.println("Inserted rows.");
		sql="select * from student";
		ResultSet result = statement.executeQuery(sql);
		while(result.next()){
			System.out.println("Student Id is :"+ result.getString(1));
			System.out.println("Student Name is :"+result.getString(2));
			System.out.println("Age is :"+result.getInt(3));
		}//end of while loop
	}//end of try block
	catch(Exception e)
	{
		e.printStackTrace();
	}//end of catch block
	
	}

}
