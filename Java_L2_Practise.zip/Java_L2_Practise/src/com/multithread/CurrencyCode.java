package com.multithread;

import java.util.Currency;
import java.util.HashSet;
import java.util.Locale;
import java.util.Scanner;
import java.util.Set;

public class CurrencyCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("All the avaible currenies are :");
		Set<Currency> s = getAllCurrencies();
		System.out.println("Availble Currencies are :"+s);
		
			
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Currency Code :");
		String currcode = sc.next();
		
		Currency c1 = Currency.getInstance(currcode);
		
		String currcc = c1.getCurrencyCode();
		String displayname = c1.getDisplayName();
		String symbol = c1.getSymbol();
		
		System.out.println("Currency code for"+currcode+" is :"+currcc+" "+displayname+" "+symbol);

	}

public static Set<Currency> getAllCurrencies(){
	Set<Currency> s = new HashSet<Currency>();
	Locale[] locs = Locale.getAvailableLocales();
	
	for(Locale loc:locs)
	{
		Currency curr=null;
		try{
			System.out.println("Local code is :"+loc);
			if(loc.toString().length()>2){
			 curr = Currency.getInstance(loc);
			}
			if(curr != null)
				s.add(curr);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	return s;
}
	
}
