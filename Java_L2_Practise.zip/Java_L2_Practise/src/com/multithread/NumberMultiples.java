/**
 * 
 */
package com.multithread;


/**
 * @author syed mustafa jibran
 *
 */
public class NumberMultiples {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	NumMultiples a1 = new NumMultiples(2);
	Thread a11 = new Thread(a1);
	System.out.println("Status of Thread a11 is:"+a11.getState());
	try{
	a11.join();
	}catch(Exception e){
		e.printStackTrace();
	}
	
	NumMultiples a2 = new NumMultiples(5);
	Thread a22 = new Thread(a2);
	System.out.println("Status of Thread a22 is :"+a22.getState());
	
	NumMultiples a3 = new NumMultiples(8);
	Thread a33 = new Thread(a3);
	System.out.println("Status of Thread a33 is :"+a33.getState());

	a11.setPriority(Thread.MIN_PRIORITY);
	a22.setPriority(Thread.MAX_PRIORITY);
	a33.setPriority(Thread.NORM_PRIORITY);
	//start of threads
	a11.start();
	a22.start();
	a33.start();
	}

}


class NumMultiples implements Runnable
{
	int n=0;
	public NumMultiples(int num) {
		// TODO Auto-generated constructor stub
		n=num;
	}
	public void run()
	{
		try{
			
		System.out.println("Number Passed is :"+n+" \n");
		for(int j=1;j<=10;j++){
			System.out.println("Multiple's are:"+(j*n)+" \n");
			//Thread.sleep(10000);
		}
		    System.out.println("End of Thread");
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
	}//End of run method
}//end of NumMultiples
