package com.multithread;

import java.io.IOException;


public class QueProcess {
	int n;
	boolean flag=false;
//Producer Method
	synchronized void put(int n){
		if(flag){
			try{
				wait();
				}// end of try block
			catch(Exception e)
			{
				e.printStackTrace();
			}// end of catch block
		}// end of if block	
		this.n=n; //produce
		System.out.println("Produce :"+n);
		flag=true;
		notify();
		}//end of put method
	
	//Consumer Method
	synchronized int get(){
		if(!flag){
			try{
				wait();
			}//end of try block
			catch(Exception e){
				e.printStackTrace();
			}//end of catch block
		}// end of if block
		
	System.out.println("Consume :"+n);
	flag=false;
	notify();
	return n;
}//end of get method

}//end of QueProcess
