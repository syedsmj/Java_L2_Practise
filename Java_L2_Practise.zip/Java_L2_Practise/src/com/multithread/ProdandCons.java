/**
 * 
 */
package com.multithread;

import java.io.IOException;

/**
 * @author syed
 *
 */
public class ProdandCons {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		QueProcess q = new QueProcess();
		new Producer(q);
		new Consumer(q);
	}

}


	
class Producer implements Runnable {
	QueProcess q;
	
	Producer(QueProcess q){
		this.q=q;
		new Thread(this).start();
	  }//end of constructor
	  public void run(){
		int i=0;
		while(true){
			q.put(i++);
			if(i==75)
				System.exit(0);
		}//end of while loop
	   }//end of run method

}// end of Producer class

class Consumer implements Runnable {
	QueProcess q;
	Consumer(QueProcess q){
		this.q=q;
		new Thread(this).start();
	}//end of constructor
	
	public void run(){
		while(true){
			q.get();
		}//end of while loop
	}//end of run method
}//end of consumer class